import os
import subprocess
import tkinter as tk
from tkinter import messagebox

print("DEBUG INFO: Launcher gestartet. - Version 0.1 BETA")
print("DEBUG INFO: Versuche, den Installer Builder zu starten...")

# Hinweis: passt den relativen Pfad unten an, falls "file\builder.exe" an einer anderen Stelle liegt.
messagebox.showinfo("Info", "Da dieses Programm noch in der BETA-Phase ist, wird das Hauptprogramm noch via dieses Launchers geöffnet.")

script_dir = os.path.dirname(os.path.abspath(__file__))
builder_path = os.path.normpath(os.path.join(script_dir, "..", "file", "builder.exe"))
# Alternativ, wenn builder.exe direkt im übergeordneten Ordner liegt:
# builder_path = os.path.normpath(os.path.join(script_dir, "..", "builder.exe"))

try:
    subprocess.run([builder_path], check=True)
    print("DEBUG INFO: Installer Builder gestartet:", builder_path)
    print("Launcher beendet. Hauptprogramm setzt fort. - Version 0.1 BETA")
except FileNotFoundError:
    messagebox.showerror("Fehler", f"Die Datei wurde nicht gefunden:\n{builder_path}")
    print("DEBUG INFO: Fehler beim Starten des Installer Builders. Datei nicht gefunden:", builder_path)
    print("Programm beendet aufgrund Fehlers. - Version 0.1 BETA")
except subprocess.CalledProcessError as e:
    messagebox.showerror("Fehler", f"Der Prozess wurde mit Fehler beendet (Code {e.returncode}).")
    print("DEBUG INFO: Fehler beim Starten des Installer Builders - Prozessfehler:", e)
    print("Programm beendet aufgrund Fehlers. - Version 0.1 BETA")