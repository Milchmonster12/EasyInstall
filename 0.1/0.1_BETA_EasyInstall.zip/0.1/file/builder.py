import tkinter as tk
from tkinter import filedialog, messagebox
import subprocess, os, shutil

BG = "#DDDDDD"
BTN = "#E0E0E0"


# Absoluten Pfad des aktuellen Skripts bestimmen
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
TEMPLATE_PATH = os.path.join(BASE_DIR, "templates", "installer_template.py")
OUTPUT_DIR = os.path.join(BASE_DIR, "output")

def build_installer(app_name, download_url, exe_name, required_mb, banner, icon):
    if not os.path.exists(OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    
    with open(TEMPLATE_PATH, "r", encoding="utf-8") as f:
        template = f.read()
    
    # Platzhalter ersetzen
    code = (
        template
        .replace("{app_name}", app_name)
        .replace("{download_url}", download_url)
        .replace("{exe_name}", exe_name)
        .replace("{required_mb}", str(required_mb))
        .replace("{banner_file}", os.path.basename(banner))
        .replace("{icon_file}", os.path.basename(icon))
    )
    code = code.replace("{icon_target}", os.path.basename(icon))

    output_script = os.path.join(OUTPUT_DIR, f"{app_name.lower()}_installer.py")
    
    with open(output_script, "w", encoding="utf-8") as f:
        f.write(code)
    
    # Dateien kopieren
    banner_target = os.path.join(OUTPUT_DIR, os.path.basename(banner))
    icon_target = os.path.join(OUTPUT_DIR, os.path.basename(icon))
    shutil.copy(banner, banner_target)
    shutil.copy(icon, icon_target)


    print("Prüfe Python Installation...")
    try:
        subprocess.run("python --version")
    except:
        messagebox.showerror("Fehler", "Python ist nicht installiert oder nicht im PATH.")
        return

    # PyInstaller ausführen
    cmd = [
        "pyinstaller", "--onefile", "--noconsole", "--noupx", "--clean",
        f"--icon={icon_target}",
        f"--add-data={banner_target}:.",
        f"--add-data={icon_target}:.",
        output_script
    ]
    
    print("Prüfe PIP Installationen...")
    subprocess.run("pip install pygame pyinstaller requests")

    print("Starte PyInstaller mit:", " ".join(cmd))
    subprocess.run(cmd)
    messagebox.showinfo("Fertig!", f"Installer für {app_name} wurde erstellt!\nSchau im 'dist'-Ordner nach.")


def beenden():
    root.destroy()
    print("DEBUG INFO: Installer Builder geschlossen.")

# GUI
root = tk.Tk()
root.title("Installer Builder")
root.geometry("650x450")
root.configure(bg=BG)
root.resizable(False, False)


tk.Label(root, text="🧩 Installer Builder", bg=BG, font=("Segoe UI", 16, "bold")).pack(pady=10)



frame = tk.Frame(root, bg=BG)
frame.pack(pady=10)

# Eingabefelder
labels = [
    ("Programmname:", "name_entry"),
    ("Download-URL:", "url_entry"),
    ("EXE-Dateiname:", "exe_entry"),
    ("Benötigter Speicher (MB):", "space_entry")
]

entries = {}
for i, (label, key) in enumerate(labels):
    tk.Label(frame, text=label, bg=BG).grid(row=i, column=0, sticky="e", padx=5, pady=5)
    entry = tk.Entry(frame, width=40)
    entry.grid(row=i, column=1, pady=5)
    entries[key] = entry

# Banner
tk.Label(frame, text="Banner-Bild:", bg=BG).grid(row=4, column=0, sticky="e", padx=5, pady=5)
banner_path = tk.StringVar()
tk.Entry(frame, textvariable=banner_path, width=30).grid(row=4, column=1, sticky="w", pady=5)
tk.Button(frame, text="Auswählen", bg=BTN,
          command=lambda: banner_path.set(filedialog.askopenfilename(filetypes=[("Bilder", "*.png;*.jpg")]))).grid(row=4, column=2, padx=5)

# Icon
tk.Label(frame, text="Icon (.ico):", bg=BG).grid(row=5, column=0, sticky="e", padx=5, pady=5)
icon_path = tk.StringVar()
tk.Entry(frame, textvariable=icon_path, width=30).grid(row=5, column=1, sticky="w", pady=5)
tk.Button(frame, text="Auswählen", bg=BTN,
          command=lambda: icon_path.set(filedialog.askopenfilename(filetypes=[("Icons", "*.ico")]))).grid(row=5, column=2, padx=5)

def on_build():
    if not all([
        entries["name_entry"].get(),
        entries["url_entry"].get(),
        entries["exe_entry"].get(),
        entries["space_entry"].get(),
        banner_path.get(),
        icon_path.get()
    ]):
        messagebox.showerror("Fehler", "Bitte alle Felder ausfüllen!")
        return
    
    build_installer(
        entries["name_entry"].get(),
        entries["url_entry"].get(),
        entries["exe_entry"].get(),
        entries["space_entry"].get(),
        banner_path.get(),
        icon_path.get()
    )

tk.Button(root, text="🛠️ Installer Erstellen", relief="raised", bg=BTN, command=on_build).pack(pady=30)
tk.Button(root, text="Beenden", relief="raised", bg=BTN, command=beenden).pack(pady=0)
tk.Label(root, text="Version 0.1 BETA", bg=BG, font=("Segoe UI", 10)).pack(pady=10)
messagebox.showwarning("Warnung", "Dieses Programm befindet sich in der BETA-Phase. Bitte überprüfe die erstellten Installer sorgfältig. Das Programm könnte Fehler enthalten.")
root.mainloop()
