import os
import zipfile
import requests
import shutil
import time
import threading
import win32com.client
from pathlib import Path
import tkinter as tk
from tkinter import ttk, messagebox
from PIL import Image, ImageTk

# ==========================================================
#   KONFIGURATION
# ==========================================================
# ==========================================================
#   KONFIGURATION
# ==========================================================
from pathlib import Path
import os

APP_NAME = "{app_name}"
DOWNLOAD_URL = "{download_url}"
INSTALL_DIR = Path(os.environ["LOCALAPPDATA"]) / APP_NAME
SHORTCUT_NAME = APP_NAME
EXECUTABLE_NAME = "{exe_name}"
REQUIRED_MB = {required_mb}

ICON_FILE = "{icon_file}"
BANNER_FILE = "{banner_file}"
ICO_FILE = "{icon_target}"

# ==========================================================
#   HILFSFUNKTIONEN
# ==========================================================

import os, sys
from PIL import Image, ImageTk




def resource_path(relative_path):
    """Funktion, um Dateien sowohl im .py- als auch im .exe-Modus zu finden"""
    try:
        base_path = sys._MEIPASS  # Ordner der temporären entpackten Ressourcen (nur bei .exe)
    except Exception:
        base_path = os.path.abspath(".")  # beim normalen Start aus VSCode oder IDLE
    return os.path.join(base_path, relative_path)


def get_free_space_mb():
    total, used, free = shutil.disk_usage("C:\\")
    return free // (2**20)


def download_file(url, dest_path, progress_callback=None, retries=3):
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    for attempt in range(retries):
        try:
            with requests.get(url, stream=True, headers=headers, timeout=20) as r:
                r.raise_for_status()
                total = int(r.headers.get("content-length", 0))
                with open(dest_path, "wb") as f:
                    downloaded = 0
                    for chunk in r.iter_content(chunk_size=8192):
                        if chunk:
                            f.write(chunk)
                            downloaded += len(chunk)
                            if progress_callback and total > 0:
                                progress_callback(downloaded / total * 100)
            return
        except Exception as e:
            if attempt < retries - 1:
                time.sleep(2)
            else:
                raise e


def extract_zip(zip_path, extract_to):
    with zipfile.ZipFile(zip_path, "r") as zip_ref:
        zip_ref.extractall(extract_to)


def create_shortcut(target, shortcut_path):
    target = Path(target)
    if not target.exists():
        raise FileNotFoundError(f"Zieldatei nicht gefunden: {target}")
    shell = win32com.client.Dispatch("WScript.Shell")
    shortcut = shell.CreateShortcut(str(shortcut_path))
    shortcut.TargetPath = str(target)
    shortcut.WorkingDirectory = str(target.parent)
    shortcut.IconLocation = str(target)
    shortcut.Save()


def perform_installation(progressbar, label, callback_done):
    """Führt die echte Installation in einem separaten Thread aus."""
    def run():
        try:
            label.config(text="Vorbereitung...")
            INSTALL_DIR.mkdir(parents=True, exist_ok=True)
            zip_path = INSTALL_DIR / "download.zip"

            # Download
            label.config(text="Lade Dateien herunter ...")
            download_file(DOWNLOAD_URL, zip_path, progress_callback=lambda p: progressbar.config(value=p))

            # Entpacken
            label.config(text="Entpacke Dateien ...")
            extract_zip(zip_path, INSTALL_DIR)
            os.remove(zip_path)

            # Desktop-Verknüpfung erstellen
            label.config(text="Erstelle Verknüpfung ...")
            desktop = Path(os.environ["USERPROFILE"]) / "Desktop"
            if not desktop.exists():
                onedrive_desktop = Path(os.environ["USERPROFILE"]) / "OneDrive" / "Desktop"
                if onedrive_desktop.exists():
                    desktop = onedrive_desktop

            shortcut_path = desktop / f"{SHORTCUT_NAME}.lnk"
            exe_file = INSTALL_DIR / EXECUTABLE_NAME
            if not exe_file.exists():
                found = list(INSTALL_DIR.rglob(EXECUTABLE_NAME))
                if found:
                    exe_file = found[0]

            if exe_file.exists():
                create_shortcut(exe_file, shortcut_path)
            else:
                create_shortcut(INSTALL_DIR, shortcut_path)

            progressbar["value"] = 100
            label.config(text="Installation abgeschlossen!")
            time.sleep(1)
            callback_done()

        except Exception as e:
            messagebox.showerror("Fehler bei der Installation", str(e))

    threading.Thread(target=run, daemon=True).start()


# ==========================================================
#   GUI / WIZARD-STRUKTUR
# ==========================================================
root = tk.Tk()
root.title(f"{APP_NAME} Setup-Assistent")
root.geometry("600x450")
root.resizable(False, False)
root.configure(bg="#D8D8D8")

try:
    icon_path = resource_path(ICO_FILE)
    root.iconbitmap(icon_path)
except Exception as e:
    print("Kein Icon gesetzt:", e)


try:
    banner_path = resource_path("banner.png")
    logo_path = resource_path("logo.png")
    print("Banner path:", banner_path)
    print("Logo path:", logo_path)

    # Dein Banner (breit)
    banner_img = Image.open(banner_path).resize((600, 80))
    banner = ImageTk.PhotoImage(banner_img)
    banner_label = tk.Label(root, image=banner, bg="#D8D8D8")
    banner_label.image = banner
    banner_label.pack(side="top", fill="x")

    # Dein Logo (klein links oben)
    logo_img = Image.open(logo_path).resize((64, 64))
    logo = ImageTk.PhotoImage(logo_img)
    logo_label = tk.Label(root, image=logo, bg="#D8D8D8")
    logo_label.image = logo
    logo_label.place(x=20, y=20)

except Exception as e:
    print("Logo/Banner konnte nicht geladen werden:", e)


container = tk.Frame(root, bg="#D8D8D8")
container.pack(fill="both", expand=True)


class WizardPage(tk.Frame):
    def __init__(self, master):
        super().__init__(master, bg="#D8D8D8")
    def show(self):
        self.lift()


class WelcomePage(WizardPage):
    def __init__(self, master):
        super().__init__(master)
        tk.Label(self, text=f"Willkommen zum Setup von {APP_NAME}", font=("Segoe UI", 14, "bold"), bg="#D8D8D8").pack(pady=40)
        tk.Label(self, text="Dieser Assistent führt Sie durch die Installation.\n\nKlicken Sie auf Weiter, um fortzufahren.",
                 font=("Segoe UI", 10), bg="#D8D8D8").pack()


class LicensePage(WizardPage):
    def __init__(self, master):
        super().__init__(master)
        tk.Label(self, text="Lizenzvereinbarung", font=("Segoe UI", 12, "bold"), bg="#D8D8D8").pack(pady=10)
        text = tk.Text(self, width=70, height=12, wrap="word")
        text.insert("1.0", "Bitte lesen Sie die folgende Lizenzvereinbarung sorgfältig durch.\n\n"
                           "Durch die Installation dieses Programms stimmen Sie den Bedingungen zu.\n\n"
                           "Dies ist ein Beispieltext für die Lizenzbedingungen.")
        text.config(state="disabled")
        text.pack(pady=10)
        self.accept_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(self, text="Ich stimme den Bedingungen zu", variable=self.accept_var).pack()


class SpacePage(WizardPage):
    def __init__(self, master):
        super().__init__(master)
        tk.Label(self, text="Speicherplatzüberprüfung", font=("Segoe UI", 12, "bold"), bg="#D8D8D8").pack(pady=20)
        self.label = tk.Label(self, bg="#D8D8D8", font=("Segoe UI", 10))
        self.label.pack(pady=10)
        self.update_space_info()

    def update_space_info(self):
        free = get_free_space_mb()
        text = (f"Für die Installation werden ca. {REQUIRED_MB} MB benötigt.\n"
                f"Verfügbarer Speicherplatz auf Laufwerk C: {free} MB.\n\n"
                f"Installationsverzeichnis: {INSTALL_DIR}")
        self.label.config(text=text)


class InstallPage(WizardPage):
    def __init__(self, master):
        super().__init__(master)
        tk.Label(self, text="Installation", font=("Segoe UI", 12, "bold"), bg="#D8D8D8").pack(pady=20)
        self.label = tk.Label(self, text="Mit einem Klick auf Weiter staren Sie die Installation.", bg="#D8D8D8")
        self.label.pack(pady=10)
        self.progress = ttk.Progressbar(self, orient="horizontal", length=400, mode="determinate")
        self.progress.pack(pady=15)

    def start_installation(self, callback_done):
        perform_installation(self.progress, self.label, callback_done)


class FinishPage(WizardPage):
    def __init__(self, master):
        super().__init__(master)
        tk.Label(self, text="Installation abgeschlossen!", font=("Segoe UI", 12, "bold"), bg="#D8D8D8").pack(pady=30)
        tk.Label(self, text=f"{APP_NAME} wurde erfolgreich installiert.", bg="#D8D8D8").pack(pady=10)
        self.run_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(self, text=f"{APP_NAME} nach dem Beenden starten", variable=self.run_var).pack(pady=10)


# ==========================================================
#   NAVIGATION
# ==========================================================
pages = {}
for P in (WelcomePage, LicensePage, SpacePage, InstallPage, FinishPage):
    page = P(container)
    pages[P.__name__] = page
    page.place(relx=0, rely=0, relwidth=1, relheight=1)

current_page_index = 0
page_order = list(pages.keys())


def show_page(index):
    global current_page_index
    current_page_index = index
    pages[page_order[index]].show()
    update_nav_buttons()


def next_page():
    global current_page_index
    if current_page_index == 1:  # Lizenzseite
        if not pages["LicensePage"].accept_var.get():
            messagebox.showwarning("Hinweis", "Sie müssen den Lizenzbedingungen zustimmen, um fortzufahren.")
            return
    if current_page_index == 2:  # Speicherplatzseite
        free = get_free_space_mb()
        if free < REQUIRED_MB:
            messagebox.showerror("Fehler", "Nicht genügend Speicherplatz vorhanden!")
            return
    if current_page_index == 3:  # Installation starten
        install_page = pages["InstallPage"]
        install_page.start_installation(lambda: show_page(4))
    else:
        show_page(current_page_index + 1)


def prev_page():
    if current_page_index > 0:
        show_page(current_page_index - 1)


def cancel_setup():
    if messagebox.askyesno("Setup beenden", "Möchten Sie das Setup wirklich abbrechen?"):
        root.destroy()


def update_nav_buttons():
    back_btn["state"] = tk.NORMAL if current_page_index > 0 else tk.DISABLED
    next_btn["text"] = "Weiter" if current_page_index < len(page_order) - 1 else "Fertigstellen"
    if current_page_index == len(page_order) - 1:
        next_btn["command"] = finish_setup
    else:
        next_btn["command"] = next_page


def finish_setup():
    finish_page = pages["FinishPage"]
    if finish_page.run_var.get():
        exe_path = INSTALL_DIR / EXECUTABLE_NAME
        if exe_path.exists():
            os.startfile(exe_path)
    root.destroy()


# ==========================================================
#   BUTTONLEISTE UNTEN
# ==========================================================
bottom_frame = tk.Frame(root, bg="#D8D8D8", height=50)
bottom_frame.pack(fill="x", side="bottom")

ttk.Separator(root, orient="horizontal").pack(fill="x", side="bottom")

back_btn = ttk.Button(bottom_frame, text="Zurück", command=prev_page)
next_btn = ttk.Button(bottom_frame, text="Weiter", command=next_page)
cancel_btn = ttk.Button(bottom_frame, text="Abbrechen", command=cancel_setup)

cancel_btn.pack(side="right", padx=10, pady=10)
next_btn.pack(side="right", padx=10, pady=10)
back_btn.pack(side="right", padx=10, pady=10)


# ==========================================================
#   START
# ==========================================================
show_page(0)
root.mainloop()
