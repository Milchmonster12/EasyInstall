INFORMATIONEN ZUR EASY INSTALL SOFTWARE
---------------------------------------
Warnung DIESE SOFTWARE IST IN DER BETA!
---------------------------------------
Version 0.1 BETA	    Lizenz: MIT
 	- offizielle Version -
1. ALLGEIMEINES
1.1 Die Software befindet sich in der BETA. Die bedeutet das Fehler in der Software sein können. Außerdem ist die Software in machen Punkten noch nicht gut gestaltet.
1.2 Die gefertigten Installierer sind bevor der Benutzung ausführlich zu prüfen!
1.3 Aktuell ist die Software nur in einem ZIP Ordner verfügbar. Sobald der offizielle Release kommt gibt es die Software auch mit einem Installierer.
1.4 Updates sind auf https://github.com/Milchmonster12/EasyInstall zu finden.
2. BENUTZUNGSINFORMATIONEN
2.1 Damit das Programm funktioniert muss Python 3.10+ auf dem Computer installiert sein und in PATH eingetragen sein. Ob dies der Fall ist prüft das Programm automatisch.
2.1.1 Um das System zu nutzen muss in Python auch via PIP Erweiterungen installiert sein: pygame pyinstaller requests. Das Programm prüft automatisch ob dies der Fall ist. Wenn nicht installiert es die Erweiterungen via PIP ( mitfolgende CMD/PS Befehl: "pip install pygame pyinstaller requests")
2.2 Beim Starten des Programms startet eine CMD mit aus folgenden Grund: 1. Um Debug Informationen zu sehen (liegt daran das dass Programm BETA ist, in der Vollversion wird dies nicht mehr der Fall sein) 2. Um den Fortschritt von Pyinstaller zu sehen (der das Setup erstellt, bald kommt Update um von Pyinstaller unabhängig zu werden.).
2.3 Die Banner Datei muss banner.png heißen. Anders funktioniert es nicht. Das Programm meldet zwar kein Fehler aber im erstellten Installierer wird die Datei nicht angezeigt. Das gleich gilt für die ICO Datei. Diese muss ico.ico heißen. -> FIX kommt
2.4 Während des erstellvorgang gibt es aktuell noch den Bug das es evtl. "Keine Rückmeldung" oben am Fenster steht. Dies ist aber normal und wird bald gefixt. In der CMD ist der fortschritt von Pyinstaller normal sichtbar
2.5 Weitere Bugs: Gerne in https://github.com/users/Milchmonster12/projects/2 eintragen!

---------------------------------------
Verson 0.1 BETA              23.10.2025